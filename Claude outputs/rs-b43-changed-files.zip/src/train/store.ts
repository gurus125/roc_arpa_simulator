import { Scenario } from "../engine/index";
import { Observation, SessionRecord } from "./record";
import { PLACEHOLDER_SCORING, ScoringConfig } from "./session";

/**
 * Everything the simulator remembers between sessions on one computer: instructor PIN, batches,
 * assignments, exercise records, instructor-made scenarios and the scoring settings. Kept in the
 * browser's local storage (or any object with the same two methods, for tests).
 *
 * The PIN only keeps students out of the instructor pages in a classroom. It is NOT security:
 * anyone with access to the computer's browser data can read or clear it.
 */
export interface Batch {
  id: string;
  name: string;
  students: string[];
  /** Exercise ids assigned to this batch (ARPA exercise ids and ROC exercise kinds). */
  assigned: string[];
}

export interface StoreData {
  version: 1;
  pin: string;
  batches: Batch[];
  records: SessionRecord[];
  scenarios: Scenario[];
  /** Radar maps: named sets of navigation lines (positions in NM), drawn by the user on the radar. */
  maps: Record<string, { e: number; n: number }[][]>;
  /** Nav marks saved with the map of the same name. */
  mapMarks: Record<string, { e: number; n: number }[]>;
  scoring: ScoringConfig;
  /** Simulated-plus-paused time each pair of students has spent at the display, seconds of wall time. */
  pairSeconds: Record<string, number>;
  /** Students allowed at one display, and the hours each pair should get. Placeholders from the plan's open question. */
  maxStudentsPerDisplay: number;
  targetHoursPerPair: number | null;
  /** Minutes of exercise time after which the next trainee of a group takes the controls; null or left out: they change by hand. */
  changeoverMin?: number | null;
  /** The instructor's observation checklist, one item a line; left out: DEFAULT_OBSERVATION_ITEMS. */
  obsItems?: string[];
  /**
   * Older records without their replay (see lightRecord), newest first: when a record is dropped to make room,
   * what the trainee file, the class comparison and the comparison of assessors need is kept here.
   */
  archive?: SessionRecord[];
  /** Observations ticked at the station, by the id of the display's record, until (and after) that record arrives. */
  pendingObs?: Record<string, { items: Observation[]; notes: string }>;
  /** The parts (exercise ids) of the two practical examinations, as the instructor has set them; left out: DEFAULT_EXAMS. */
  exams?: { roc: string[]; arpa: string[] };
  /** Own ship particulars and voyage data typed in by the user (as on an AIS). Starting values are placeholders, not a real ship. */
  ownShip: {
    name: string; callSign: string; imo: string; mmsi: string; draughtM: number | null; hazardous: string; destination: string; eta: string;
    /** Where the radar antenna is from the reference point (CCRP), metres ahead (+) and to starboard (+). Only places the antenna mark on the outline. Older stores: absent, read as 0. */
    antennaAheadM?: number; antennaStbdM?: number;
  };
  /** Display palette. */
  displayMode: "day" | "night";
  /** Keys of a hardware control panel chosen by the user, by function (see ui/panel-map.ts). Empty: the default keys. */
  panelKeys: Record<string, string>;
  /**
   * Two sets of control settings the user has stored, to recall later (IEC 62388 13.5.1: at least two).
   * Each maps a control's id to its value (or checked state). Null: nothing stored.
   */
  userSettings: (Record<string, string | boolean> | null)[];
}

export interface KeyValue {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export const STORE_KEY = "radar-sim-store-v1";
export const DEFAULT_PIN = "0000";
export const MAX_RECORDS = 60;
/** Older records kept without their replay. */
export const MAX_ARCHIVE = 300;

/**
 * A record without its replay: no frames, coastline or radio log, only the flagged events, and no criteria rows
 * or debrief questions. What is left is what the trainee file and the comparisons use: who, when, the marked
 * items, who was at the controls, the observations, the decisions and the measured facts.
 */
export function lightRecord(r: SessionRecord): SessionRecord {
  const light: SessionRecord = {
    ...r, names: {}, coasts: [], frames: [], events: r.events.filter((e) => e.flag !== undefined),
    result: r.result ? { ...r.result, debrief: [] } : null,
    ...(r.criteria ? { criteria: { ...r.criteria, rows: [] } } : {}),
  };
  delete light.comms;
  return light;
}

export function emptyStore(): StoreData {
  return {
    version: 1, pin: DEFAULT_PIN, batches: [], records: [], scenarios: [], maps: {}, mapMarks: {},
    scoring: JSON.parse(JSON.stringify(PLACEHOLDER_SCORING)) as ScoringConfig,
    pairSeconds: {}, maxStudentsPerDisplay: 2, targetHoursPerPair: null,
    ownShip: { name: "TRAINING SHIP", callSign: "TRNG1", imo: "0000000", mmsi: "000000000", draughtM: null, hazardous: "None", destination: "", eta: "", antennaAheadM: 0, antennaStbdM: 0 },
    displayMode: "day",
    panelKeys: {},
    userSettings: [null, null],
  };
}

export const pairKey = (students: string[]): string => [...students].map((s) => s.trim().toLowerCase()).filter(Boolean).sort().join(" + ");

export class Store {
  data: StoreData;
  private kv: KeyValue | null;

  constructor(kv: KeyValue | null) {
    this.kv = kv;
    this.data = emptyStore();
    try {
      const raw = kv?.getItem(STORE_KEY);
      if (raw) {
        const d = JSON.parse(raw) as Partial<StoreData>;
        if (d && d.version === 1) {
          // Tolerances and points added in later versions keep their placeholders.
          const def = emptyStore().scoring;
          const sc: Partial<ScoringConfig> = d.scoring ?? {};
          this.data = { ...emptyStore(), ...d, scoring: { ...def, ...sc, tol: { ...def.tol, ...(sc.tol ?? {}) }, points: { ...def.points, ...(sc.points ?? {}) } } };
        }
      }
    } catch {
      // Unreadable data: start empty rather than stop the simulator.
    }
  }

  /** Returns false when the browser refused to store (storage full or blocked). */
  save(): boolean {
    try {
      this.kv?.setItem(STORE_KEY, JSON.stringify(this.data));
      return true;
    } catch {
      return false;
    }
  }

  checkPin(pin: string): boolean {
    return pin === this.data.pin;
  }

  setPin(pin: string): boolean {
    if (!/^\d{4,8}$/.test(pin)) return false;
    this.data.pin = pin;
    return this.save();
  }

  addBatch(name: string): Batch | null {
    const n = name.trim();
    if (!n || this.data.batches.some((b) => b.name.toLowerCase() === n.toLowerCase())) return null;
    const b: Batch = { id: `b${Date.now().toString(36)}${this.data.batches.length}`, name: n, students: [], assigned: [] };
    this.data.batches.push(b);
    this.save();
    return b;
  }

  removeBatch(id: string): void {
    this.data.batches = this.data.batches.filter((b) => b.id !== id);
    this.save();
  }

  setStudents(batchId: string, names: string[]): void {
    const b = this.data.batches.find((x) => x.id === batchId);
    if (!b) return;
    b.students = [...new Set(names.map((s) => s.trim()).filter(Boolean))];
    this.save();
  }

  setAssigned(batchId: string, ids: string[]): void {
    const b = this.data.batches.find((x) => x.id === batchId);
    if (!b) return;
    b.assigned = [...new Set(ids)];
    this.save();
  }

  /** Newest first; the oldest are dropped beyond MAX_RECORDS. If storage is full, older ones are dropped until it fits. */
  addRecord(r0: SessionRecord): boolean {
    // A display sends a record again when the trainees save their debrief: what the assessor and the instructor
    // added to it at this station (the decision, the observations) stays.
    const old = this.data.records.find((x) => x.id === r0.id);
    const r: SessionRecord = old ? {
      ...r0,
      ...(r0.assessor === undefined && old.assessor ? { assessor: old.assessor } : {}),
      ...(r0.assessorBy === undefined && old.assessorBy ? { assessorBy: old.assessorBy } : {}),
      ...(r0.observations === undefined && old.observations ? { observations: old.observations } : {}),
      ...(r0.observerNotes === undefined && old.observerNotes ? { observerNotes: old.observerNotes } : {}),
      ...(r0.debriefDone === undefined && old.debriefDone ? { debriefDone: old.debriefDone } : {}),
    } : r0;
    const all = [r, ...this.data.records.filter((x) => x.id !== r.id)];
    this.data.records = all.slice(0, MAX_RECORDS);
    this.toArchive(all.slice(MAX_RECORDS));
    if (this.data.archive) this.data.archive = this.data.archive.filter((x) => x.id !== r.id);
    while (!this.save()) {
      // Storage is full: the oldest replay goes first (its light copy stays), then the oldest of the archive.
      if (this.data.records.length > 1) this.toArchive([this.data.records.pop()!]);
      else if (this.data.archive && this.data.archive.length > 0) this.data.archive.pop();
      else return false;
    }
    return true;
  }

  private toArchive(dropped: SessionRecord[]): void {
    if (dropped.length === 0) return;
    const ids = new Set(dropped.map((d) => d.id));
    this.data.archive = [...dropped.map(lightRecord), ...(this.data.archive ?? []).filter((x) => !ids.has(x.id))].slice(0, MAX_ARCHIVE);
  }

  /** Every exercise on record, newest first: the full records, then the older ones kept without their replay. */
  history(): SessionRecord[] {
    return [...this.data.records, ...(this.data.archive ?? [])];
  }

  removeRecord(id: string): void {
    this.data.records = this.data.records.filter((r) => r.id !== id);
    if (this.data.archive) this.data.archive = this.data.archive.filter((r) => r.id !== id);
    this.save();
  }

  saveScenario(sc: Scenario): void {
    this.data.scenarios = [sc, ...this.data.scenarios.filter((s) => s.id !== sc.id)];
    this.save();
  }

  removeScenario(id: string): void {
    this.data.scenarios = this.data.scenarios.filter((s) => s.id !== id);
    this.save();
  }

  addPairTime(students: string[], seconds: number): void {
    const k = pairKey(students);
    if (!k || seconds <= 0) return;
    this.data.pairSeconds[k] = (this.data.pairSeconds[k] ?? 0) + seconds;
  }

  pairHours(students: string[]): number {
    return (this.data.pairSeconds[pairKey(students)] ?? 0) / 3600;
  }
}
