import { World } from "../engine/index";
import { ArpaSystem } from "../arpa/index";
import { ExerciseResult, TaskCriterion } from "./session";
import type { ProgressReport } from "./attention";

/** One moment of an exercise, kept for the debrief replay. Positions in NM (east, north). */
export interface Frame {
  t: number;
  own: { e: number; n: number; hdg: number; spd: number; ordC: number; ordS: number };
  tg: { id: number; e: number; n: number; c: number; s: number }[];
  /** Number of targets tracked by the ARPA and the alarms not yet acknowledged. */
  tracks: number;
  alarms: string[];
}

export interface RecordEvent {
  t: number;
  text: string;
  /** True when only the instructor should see it during the exercise (it reveals the truth). */
  instructor: boolean;
  /** A bookmark for the debrief: an attention flag raised at this moment, and how urgent it was (3 most). */
  flag?: 1 | 2 | 3;
}

/** One item of the instructor's observation checklist, as ticked for one display during one exercise. */
export interface Observation {
  item: string;
  /** "yes": seen done well; "no": seen not done or done badly; left out of the list: not observed. */
  mark: "yes" | "no";
  /** Exercise time on the display when it was ticked, seconds, and the trainee it is about ("" for the whole group). */
  t: number;
  student: string;
}

export interface SessionRecord {
  id: string;
  exerciseId: string;
  title: string;
  kind: "arpa" | "roc" | "free";
  students: string[];
  batch: string;
  startedIso: string;
  simSeconds: number;
  /** Target names by id, for the replay labels. */
  names: Record<number, string>;
  coasts: { e: number; n: number }[][];
  frames: Frame[];
  events: RecordEvent[];
  result: ExerciseResult | null;
  /** For ROC exercises: marks out of the maximum, as text lines. */
  summary: string[];
  /**
   * Debrief and assessment (STCW A-I/12 paragraphs 7 and 8): the trainees' own review, peer
   * comments, goals, and the assessor's decision, which is the prime criterion, not the score.
   */
  debrief?: { self: string; peer: string; goals: string };
  assessor?: { decision: "" | "competent" | "not-yet"; remarks: string; name: string };
  /** Radio messages exchanged during the exercise. */
  comms?: { t: number; from: string; text: string }[];
  /** Who was at the controls, from when (exercise time, s): the trainee named on the display, in order. */
  controls?: { t: number; name: string }[];
  /** The instructor's observation checklist for this exercise, and his or her notes, added at the station. */
  observations?: Observation[];
  observerNotes?: string;
  /** The assessor's decision for each trainee of a group, by name (the single `assessor` decision stands for the group). */
  assessorBy?: Record<string, { decision: "" | "competent" | "not-yet"; remarks: string }>;
  /** How the exercise was marked when it was taken: the criteria and limits in force then, so that later changes of the settings do not alter what an old result means. */
  criteria?: { atIso: string; rows: TaskCriterion[]; passPercent: number | null; timeLimitMin: number | null };
  /** What the simulator measured, as short lines by subject (see train/assess.ts), and the progress figures at the end. */
  evidence?: Record<string, string>;
  progress?: ProgressReport;
  /** The guided debrief: which steps were done, the goals agreed, and when. */
  debriefDone?: { steps: boolean[]; goals: string; atIso: string };
  /** When the exercise was one part of a practical examination: which examination (one id for each sitting), its name, and which part of how many. */
  exam?: { id: string; name: string; part: number; of: number };
}

export const FRAME_INTERVAL_SEC = 10;

/** Samples the simulation every FRAME_INTERVAL_SEC and collects the ARPA's event log. */
export class Recorder {
  readonly rec: SessionRecord;
  private nextAt = 0;
  private seenEvents = 0;

  constructor(init: Pick<SessionRecord, "exerciseId" | "title" | "kind" | "students" | "batch">, w: World, nowIso: string) {
    this.rec = {
      ...init,
      id: `${nowIso}-${init.exerciseId}`,
      startedIso: nowIso,
      simSeconds: 0,
      names: Object.fromEntries(w.targets.map((t) => [t.id, t.name])),
      coasts: w.coasts.map((c) => c.points.map((p) => ({ e: +p.e.toFixed(3), n: +p.n.toFixed(3) }))),
      frames: [],
      events: [],
      result: null,
      summary: [],
    };
  }

  note(w: World, text: string, instructor = false, flag?: 1 | 2 | 3): void {
    this.rec.events.push({ t: Math.round(w.time), text, instructor, ...(flag ? { flag } : {}) });
  }

  /** The trainee at the controls from now on. */
  atControls(w: World, name: string): void {
    const list = (this.rec.controls ??= []);
    if (list[list.length - 1]?.name === name) return;
    list.push({ t: Math.round(w.time), name });
    if (list.length > 1) this.note(w, `${name || "Nobody named"} takes the controls.`, false);
  }

  /** Call after every simulation step. */
  sample(w: World, a: ArpaSystem | null): void {
    this.rec.simSeconds = w.time;
    if (a) {
      for (; this.seenEvents < a.events.length; this.seenEvents++) {
        const e = a.events[this.seenEvents]!;
        this.rec.events.push({ t: Math.round(e.time), text: e.text, instructor: e.instructor });
      }
      if (this.seenEvents > a.events.length) this.seenEvents = a.events.length;
    }
    if (w.time + 1e-9 < this.nextAt) return;
    this.nextAt = w.time + FRAME_INTERVAL_SEC;
    const r3 = (x: number): number => Math.round(x * 1000) / 1000;
    for (const t of w.targets) if (!(t.id in this.rec.names)) this.rec.names[t.id] = t.name;
    this.rec.frames.push({
      t: Math.round(w.time),
      own: { e: r3(w.own.pos.e), n: r3(w.own.pos.n), hdg: Math.round(w.own.heading * 10) / 10, spd: Math.round(w.own.speedThroughWater * 10) / 10, ordC: w.own.ordered.course, ordS: w.own.ordered.speed },
      tg: w.targets.map((t) => ({ id: t.id, e: r3(t.pos.e), n: r3(t.pos.n), c: Math.round(t.course), s: Math.round(t.speed * 10) / 10 })),
      tracks: a ? a.activeCount() : 0,
      alarms: a ? a.alarms.filter((x) => !x.acked).map((x) => x.text) : [],
    });
  }
}

/** The frame in force at simulation time `t` (the last one at or before it). */
export function frameAt(rec: SessionRecord, t: number): Frame | null {
  let best: Frame | null = null;
  for (const f of rec.frames) {
    if (f.t <= t) best = f;
    else break;
  }
  return best ?? rec.frames[0] ?? null;
}

/**
 * The frame for time t with the positions of own ship and of each target moved in a straight line
 * towards the next frame, so that a slow replay runs smoothly between the 10-second samples.
 * Everything else (heading, speed, alarms) is as recorded in the frame at or before t.
 */
export function frameInterpolated(rec: SessionRecord, t: number): Frame | null {
  const a = frameAt(rec, t);
  if (!a) return null;
  const b = rec.frames[rec.frames.indexOf(a) + 1];
  if (!b || b.t <= a.t || t <= a.t) return a;
  const f = Math.min(1, (t - a.t) / (b.t - a.t));
  const mix = (p: number, q: number): number => p + (q - p) * f;
  return {
    ...a,
    own: { ...a.own, e: mix(a.own.e, b.own.e), n: mix(a.own.n, b.own.n) },
    tg: a.tg.map((x) => {
      const y = b.tg.find((z) => z.id === x.id);
      return y ? { ...x, e: mix(x.e, y.e), n: mix(x.n, y.n) } : x;
    }),
  };
}

/** One recorded radar picture: exercise time in seconds and the picture as a JPEG data URL. Kept apart from the record (see ui/picture-store). */
export interface PictureFrame {
  t: number;
  url: string;
}

/** The radar picture is recorded this often (seconds of exercise time), this many pixels square, at this JPEG quality. */
export const PICTURE_INTERVAL_SEC = 15;
export const PICTURE_SIZE_PX = 480;
export const PICTURE_QUALITY = 0.5;
/** Most pictures kept for one exercise (three hours at the interval above); beyond it the oldest are dropped. */
export const MAX_PICTURES = 720;

/** The picture to show at exercise time `t`: the last one recorded at or before it (the first one before any). Null when there are none. */
export function pictureAt(pictures: PictureFrame[], t: number): PictureFrame | null {
  let best: PictureFrame | null = null;
  for (const p of pictures) {
    if (p.t <= t) best = p;
    else break;
  }
  return best ?? pictures[0] ?? null;
}

/** Replay speeds offered to the instructor: slow motion, real time and rapid (times real time). */
export const REPLAY_SPEEDS = [0.25, 0.5, 1, 2, 5, 10, 30, 60] as const;

const csvCell = (x: string | number): string => {
  const s = String(x);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export const toCsv = (rows: (string | number)[][]): string => rows.map((r) => r.map(csvCell).join(",")).join("\r\n") + "\r\n";

/** One line per exercise record: who, what, when, score. */
export function recordsCsv(records: SessionRecord[]): string {
  const rows: (string | number)[][] = [["Started", "Batch", "Students", "Exercise", "Minutes (simulated)", "Score", "Maximum", "Percent", "Result", "Assessor decision", "Assessor", "Assessor remarks"]];
  for (const r of records) {
    const res = r.result;
    rows.push([
      r.startedIso, r.batch, r.students.join(" / "), r.title, (r.simSeconds / 60).toFixed(1),
      res ? res.score : "", res ? res.max : "", res ? res.percent.toFixed(0) : "",
      res ? (res.passed === null ? "no pass mark set" : res.passed ? "pass" : "not yet") : r.summary.join("; "),
      r.assessor?.decision === "competent" ? "competent" : r.assessor?.decision === "not-yet" ? "not yet competent" : "", r.assessor?.name ?? "", r.assessor?.remarks ?? "",
    ]);
  }
  return toCsv(rows);
}

/** Item-by-item result of one record. */
export function resultCsv(r: SessionRecord): string {
  const rows: (string | number)[][] = [["Item", "Type", "Student", "Correct", "OK", "Points", "Maximum"]];
  for (const i of r.result?.items ?? []) rows.push([i.label, i.kind, i.student, i.correct, i.ok ? "yes" : "no", i.points, i.max]);
  return toCsv(rows);
}

/** Seconds each trainee was at the controls during a recorded exercise, in the order they first took them. */
export function controlsShare(rec: Pick<SessionRecord, "controls" | "simSeconds">): { name: string; seconds: number }[] {
  const out = new Map<string, number>();
  const list = rec.controls ?? [];
  list.forEach((c, i) => {
    const until = list[i + 1]?.t ?? rec.simSeconds;
    out.set(c.name, (out.get(c.name) ?? 0) + Math.max(0, until - c.t));
  });
  return [...out].map(([name, seconds]) => ({ name, seconds }));
}

/** The bookmarks of a record: the moments at which an attention flag was raised, most urgent kinds included, in time order. */
export function bookmarks(rec: Pick<SessionRecord, "events">): RecordEvent[] {
  return rec.events.filter((e) => e.flag !== undefined).sort((a, b) => a.t - b.t);
}
